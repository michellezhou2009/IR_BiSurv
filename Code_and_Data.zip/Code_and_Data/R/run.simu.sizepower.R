library(IRtests)
library(tidyverse)
library(copula)
nrep = 500
nsamp.all = c(100, 300, 600)
tau.all = c(0.3, 0.5, 0.7)
cen.dist.all = c("none", "exp-0.2", "exp-0.4", "exp-0.7")
res.dir = "R/run_results/"
setting.all = cross(list(nsamp = nsamp.all, tau = tau.all))

execute.fun <- function(copula.true, copula.fit, nrep, seed1 = 1234){
  ncl = detectCores(logical = FALSE)
  cl = makeCluster(ncl)
  registerDoSNOW(cl)
  lapply(setting.all, function(setting){
    nsamp = setting$nsamp;  tau = setting$tau
    switch(copula.true,
           "joe" = {
             cc = joeCopula(copula::copJoe@iTau(tau))
           },
           "clayton" = {
             cc = claytonCopula(copula::copClayton@iTau(tau))
           },
           "frank" = {
             cc = cfrankCopula(copula::copFrank@iTau(tau))
           },
           "normal" = {
             theta = round(sin(tau * pi / 2), 1); 
             cc=normalCopula(theta)
           }
    )
    set.seed(seed1)
    seed0 = round(runif(nrep, 10, 100000000))
    lapply(1:nrep, function(k){
      filenm = paste0("TRUE", copula.true, "_FIT", copula.fit, 
                      "_nsamp", nsamp, "_tau", tau, "_rep", k)
      if (!file.exists(paste0(res.dir, filenm, "_", seed1, ".RData"))){
        cat(filenm, ":", sep="")
        t0 = Sys.time()
        set.seed(seed0[k])
        uu = rCopula(nsamp, cc)
        T1 = qexp(1 - uu[,1], rate = 1)
        T2 = qexp(1 - uu[,2], rate = 1)
        res = lapply(cen.dist.all, function(cen.dist0){
          if (cen.dist0 != "none") {
            cen.rate = as.numeric(strsplit(cen.dist0, split = "-")[[1]][2])
            cen.dist = as.character(strsplit(cen.dist0, split = "-")[[1]][1])
          } else {
            cen.dist = cen.dist0
            cen.rate = NULL
          }
          switch(cen.dist,
                 "none"={
                   x1 = T1; x2 = T2
                   d1 = d2 = rep(1, length(T1))
                 },
                 "exp"={
                   C1 = C2 = rexp(nsamp, rate = 1 / (1 - cen.rate) - 1)
                   x1 = pmin(T1, C1); x2 = pmin(T2, C2); 
                   d1 = ifelse(T1 <= C1, 1, 0); d2 = ifelse(T2 <= C2, 1, 0)
                 }
          )
          out = IRtest_BiSurvCopula(
            x1, x2, d1, d2, 
            copula.fam = copula.fit, 
            control = list(yes.boot = TRUE, nboot = 500, 
                           seed1 = seed0[k], same.cen = T))
          rbind(
            data.frame("stat" = "IR", "type" = "original",value = out$IR),
            data.frame("stat" = "IR", "type" = "boot", value = out$IR.boot),
            data.frame("stat" = "pval", "type" = names(out$pval),
                       value = out$pval)
          ) %>% 
            mutate(
              rep = k, nsamp = nsamp, tau = tau, 
              true = copula.true, fit = copula.fit, dist = cen.dist0
            )
          }) %>% do.call(rbind,.) 
        save(res,file=paste0(res.dir, filenm, "_", seed1, ".RData"))
        print(Sys.time() - t0)
      }
    })
  }) 
  stopCluster(cl)
}

copula.fam.all = c("clayton", "frank", "joe", "normal")
for (copula.true in copula.fam.all){
  for (copula.fit in copula.fam.all){
    execute.fun(copula.true = copula.true, copula.fit = copula.fit, 
                nrep = nrep, seed1=20210601)
  }
}
