IM.fun = function(u1,u2,d1,d2, copula.fam){
  
  if (length(unique(c(length(u1), length(u2), length(d1), length(d2)))) > 1) 
    stop("The length of \"x1\", \"x2\", \"d1\", and \"d2\" has to be same.")
  if (any(is.na(d1))) stop("Missing values in \"d1\".")
  if (any(is.na(d2))) stop("Missing values in \"d2\".")
  if (any(is.na(u1))) stop("Missing values in \"u1\".")
  if (any(is.na(u2))) stop("Missing values in \"u2\".")
  if (length(setdiff(unique(d1), c(0,1))) > 0) 
    stop("Values in \"d1\" can only be 0 or 1.")
  if (length(setdiff(unique(d2), c(0,1))) > 0) 
    stop("Values in \"d2\" can only be 0 or 1.")
  if(!(copula.fam%in% c("joe", "gumbel", "clayton", "frank", "gaussian"))){
    stop("'copula.fam' should be one of 'joe','gumbel',
         'clayton','frank','gaussian'")
  }
  
  # obtain the initial value of theta using the relationship between copula parameter and kendall's tau
  switch(copula.fam,
         "joe" = {
           theta.ini = copJoe@iTau(cor(u1, u2, method = "kendall"))},
         "clayton"={
           theta.ini = copClayton@iTau(cor(u1, u2, method = "kendall"))
         },
         "frank"={
           theta.ini = copFrank@iTau(cor(u1, u2, method = "kendall"))
         },
         "gumbel"={
           theta.ini = copGumbel@iTau(cor(u1, u2, method = "kendall"))
         },
         "gaussian" = {
           theta.ini = cor(u1, u2)
         }
  )
  
  # define boundary value of optimization
  low = c(1, 1, rep(0,3)); up = c(40, 40, 40, 37, 1);
  names(low) = names(up) = c("joe", "gumbel", "clayton", "frank", "gaussian")
  
  pseudoMLE.out = optim(theta.ini, nlik, u1 = u1, u2 = u2, d1 = d1, d2 = d2, 
                        copula.fam = copula.fam, method = "Brent", 
                        lower = low[copula.fam], upper = up[copula.fam], hessian=T)
  theta.est = pseudoMLE.out$par
  ii = pseudoMLE.out$hessian / length(u1)
  if (!is.na(ii)) ii_inv = try(solve(ii), silent=T) else ii_inv=NA
  
  if (!is.character(ii_inv) & !is.na(ii_inv)) {
    ss = numDeriv::jacobian(nlik1, x = theta.est, u1 = u1, u2 = u2, 
                            d1 = d1, d2 = d2,copula.fam = copula.fam)
    ss = ss[complete.cases(ss), , drop = F]
    V = t(ss) %*% ss / length(u1); 
    IR.stat = sum(diag(ii_inv %*% V))
    IM.stat = as.vector(V - ii)
    logIM.stat = log(IR.stat)
  } else {
    IR.stat = IM.stat = logIM.stat = NA
    warning("The sensitivity matrix cannot be calucated.")
  }
  return(list(theta.est = theta.est, IR = IR.stat, IM = IM.stat, 
              logIM = logIM.stat))
}

IMtests_BiSurvCopula = 
  function(x1, x2, d1, d2, copula.fam, 
           control = list(yes.boot = TRUE, nboot = 500, 
                          seed1 = 1234, same.cen = FALSE)){
    
    # checking d1/d2 has other values than 0/1
    # checking whether x1, x2, d1, d2 any missing data
    # checking dimensions
    # checking whether copula.fam is not included in the R package
    if (length(unique(c(length(u1), length(u2), length(d1), length(d2)))) > 1) 
      stop("The length of \"x1\", \"x2\", \"d1\", and \"d2\" has to be same.")
    if (any(is.na(d1))) stop("Missing values in \"d1\".")
    if (any(is.na(d2))) stop("Missing values in \"d2\".")
    if (any(is.na(u1))) stop("Missing values in \"u1\".")
    if (any(is.na(u2))) stop("Missing values in \"u2\".")
    if (length(setdiff(unique(d1), c(0,1))) > 0) 
      stop("Values in \"d1\" can only be 0 or 1.")
    if (length(setdiff(unique(d2), c(0,1))) > 0) 
      stop("Values in \"d2\" can only be 0 or 1.")
    if(!(copula.fam%in% c("joe", "gumbel", "clayton", "frank", "gaussian"))){
      stop("'copula.fam' should be one of 'joe','gumbel',
         'clayton','frank','gaussian'")
    }
    
    seed1 = control$seed1
    yes.boot = control$yes.boot
    nboot = control$nboot
    same.cen=control$same.cen
    
    nsamp = length(x1)
    update.out = update.data(x1, x2, d1, d2, type = "surv")
    distfun.t1 = update.out$distfun.t1; distfun.t2 = update.out$distfun.t2
    
    out = IM.fun(u1 = update.out$u1, u2 = update.out$u2, d1, d2, copula.fam)
    theta_est = out$theta.est
    IR = out$IR
    IM = out$IM
    logIM = out$logIM
    teststat = c(IR = IR, IM = IM, logIM = logIM)
    
    if (yes.boot) {
      if (same.cen){
        distfun.c = survfit(Surv(pmax(x1, x2), 1 * (d1 == 0 | d2 == 0)) ~ 1, 
                            se.fit = F, type = "fh2")
      } else {
        distfun.c1 = survfit(Surv(x1, 1 - d1) ~ 1, se.fit = F, type = "fh2")
        distfun.c2 = survfit(Surv(x2, 1 - d2) ~ 1, se.fit = F, type = "fh2")
      }
      set.seed(seed1)
      seeds_b = round(runif(nboot, 10, 100000))
      
      boot_out = 
        foreach (b = 1 : nboot,
                 .packages=c("survival", "copula", "numDeriv"),
                 .combine = rbind) %dopar% {
                   set.seed(seeds_b[b])
                   source("R/helpers.R")
                   # generate the bivariate event times (T1,T2)
                   cc_b = getCopula(copula.fam, theta_est)
                   uu_b = rCopula(nsamp, cc_b)
                   t1_b = inv_surv(uu_b[ , 1], distfun.t1)
                   t2_b = inv_surv(uu_b[ , 2], distfun.t2)
                   # generate the censoring through the inverse of its empirical survival
                   if (same.cen) 
                     c1_b = c2_b = inv_surv(runif(nrow(uu_b)), distfun.c) else {
                       c1_b = inv_surv(runif(nrow(uu_b)), distfun.c1)
                       c2_b = inv_surv(runif(nrow(uu_b)), distfun.c2)
                     }
                   # generate bootstrap data
                   x1_b = pmin(t1_b, c1_b); x2_b = pmin(t2_b, c2_b)
                   d1_b = ifelse(t1_b <= c1_b, 1, 0); 
                   d2_b = ifelse(t2_b <= c2_b, 1, 0)
                   update.b = update.data(x1_b, x2_b, d1_b, d2_b)
                   out_b = IM.fun(u1 = update.b$u1, u2 = update.b$u2,
                                  d1 = d1_b, d2 = d2_b, copula.fam)
                   c(out_b$IR, out_b$IM, out_b$logIM)
                 }
      SE.boot = apply(boot_out, 2, sd, na.rm = T)
      pval = pnorm(abs(teststat - c(1, 0, 0)) / SE.boot, lower = F) * 2
      names(pval) = names(teststat)
      } else {boot_out = NA; pval=NA}
    return(list("theta_est" = theta_est, teststat = teststat, "pval" = pval, 
                boot = boot_out))
  }
