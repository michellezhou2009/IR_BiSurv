Title: Information matrix equivalence in the presence of censoring: A goodness-of-fit test for semiparametric copula models with multivariate survival data

Authors: Qian M. Zhou

Corresponding Author of Code: Qian M. Zhou (qz70@msstate.edu)


The code to reproduce the plots and results of the article is demonstrated in the R markdown document IRBiSurv_DataSimulation.Rmd / IRBiSurv_DataSimulation.html. 

- The folder "R" includes all the R files.

- The folder "RData" includes the results of Data Example (Section 6) and some of the simulation results. 


- The folder "TablesFigure" include the tables and figures in the manuscript (file names started with "tab" or "fig") and those in the supplementary material (file names started with "Sfig").

- The results presented in Section 5.3 are saved in a .zip file and shared on Zenodo with the DOI: 10.5281/zenodo.6480499. You can download the zipped file "res_sizepower.zip" and unzip it under "Code_and_Data".  


The code was produced with the following versions of R and packages:

R version 4.0.2 (2020-06-22)Platform: x86_64-apple-darwin17.0 (64-bit)Running under: macOS  10.16Matrix products: defaultLAPACK: /Library/Frameworks/R.framework/Versions/4.0/Resources/lib/libRlapack.dyliblocale:[1] en_US.UTF-8/en_US.UTF-8/en_US.UTF-8/C/en_US.UTF-8/en_US.UTF-8attached base packages:[1] parallel  stats     graphics  grDevices utils     datasets  methods   base     other attached packages: [1] IRtests_0.1.0       doSNOW_1.0.18       snow_0.4-3          iterators_1.0.12    [5] foreach_1.5.0       numDeriv_2016.8-1.1 forcats_0.5.0       stringr_1.4.0       [9] dplyr_1.0.0         purrr_0.3.4         readr_1.3.1         tidyr_1.1.0        [13] tibble_3.1.2        ggplot2_3.3.5       tidyverse_1.3.0     copula_1.0-1       [17] survival_3.1-12    loaded via a namespace (and not attached): [1] VineCopula_2.4.3 httr_1.4.2       jsonlite_1.7.2   splines_4.0.2    modelr_0.1.8     [6] assertthat_0.2.1 stats4_4.0.2     blob_1.2.1       cellranger_1.1.0 yaml_2.2.1      [11] pbivnorm_0.6.0   pillar_1.6.1     backports_1.1.8  lattice_0.20-41  glue_1.4.2      [16] digest_0.6.27    rvest_1.0.0.9000 colorspace_2.0-2 Matrix_1.2-18    pcaPP_1.9-73    [21] pkgconfig_2.0.3  broom_0.7.6      haven_2.3.1      mvtnorm_1.1-1    scales_1.1.1    [26] ADGofTest_0.3    generics_0.0.2   farver_2.1.0     ellipsis_0.3.2   withr_2.4.2     [31] cli_3.0.1        magrittr_2.0.1   crayon_1.4.1     readxl_1.3.1     fs_1.5.0        [36] fansi_0.5.0      MASS_7.3-51.6    gsl_2.1-6        xml2_1.3.2       tools_4.0.2     [41] hms_0.5.3        lifecycle_1.0.0  pspline_1.0-18   munsell_0.5.0    reprex_0.3.0    [46] stabledist_0.7-1 compiler_4.0.2   rlang_0.4.11     grid_4.0.2       rstudioapi_0.13 [51] labeling_0.4.2   gtable_0.3.0     codetools_0.2-16 DBI_1.1.1        R6_2.5.0        [56] lubridate_1.7.9  knitr_1.29       utf8_1.2.1       stringi_1.6.2    Rcpp_1.0.7      [61] vctrs_0.3.8      dbplyr_1.4.4     tidyselect_1.1.0 xfun_0.15       