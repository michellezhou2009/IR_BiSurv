nrep = 500; 
setting.all = purrr::cross(list(nsamp = nsamp.all, tau = tau.all))
seed1 = 20210601
file.dir = "R/run_results/"

ncl = 4
cl = makeCluster(ncl)
registerDoSNOW(cl)
summary.all = NULL
for (copula.true in copula.fam.all){
  for (copula.fit in copula.fam.all){
    for (setting in setting.all){
      nsamp = setting$nsamp;  tau = setting$tau
      cat("TRUE_", copula.true, "_FIT", copula.fit, "_nsamp", 
          nsamp, "_tau", tau, "\n", sep = "")
      res.all = foreach (k = 1 : nrep, .combine = rbind, 
                         .packages = c("dplyr", "tidyr")) %dopar% 
        {
          filenm = paste0(file.dir, "true_", copula.true, "/TRUE", 
                          copula.true, "_FIT", copula.fit, 
                          "_nsamp", nsamp, "_tau", tau, "_rep", k, 
                          "_", seed1, ".RData")
          if (file.exists(filenm)){
            load(filenm)
            res %>% 
              select(value, para, boot, dist) %>% mutate(rep = k)
          } 
        }
      res = res.all %>% split(., .$dist) %>%
        lapply(., function(res){
          res1 = res %>% filter(para != "theta") %>%
            spread(key = para, value = "value") %>%
            mutate(IR = Vmat / Smat - 1, IM = Vmat - Smat)
          res1$logIM = rep(NA, nrow(res1))
          index = which(res1$Smat > 0 & res1$Vmat > 0)
          res1$logIM[index] = log(res1$Smat[index]) - log(res1$Vmat[index])
          res1 = res1 %>% select(- Smat, - Vmat) %>%
            gather(IR : logIM, key = "test", value = "value")
          est = res1 %>% filter(boot == 0) %>% 
            mutate(est = value) %>% select(- value, - boot)
          boot.dat = res1 %>% filter(boot > 0) 
          boot.avg = boot.dat %>%
            group_by(test, rep) %>% 
            summarise(avg = mean(value, na.rm = T)) %>%
            ungroup() 
          boot.dat = boot.dat %>% left_join(., boot.avg) %>%
            mutate(est.b = value - avg) %>%
            select(- value, - avg) %>%
            left_join(., est) 
          tmp = boot.dat %>%
            group_by(test, rep) %>%
            summarise(
              pval = pnorm(abs(unique(est) / sd(est.b)), lower = F) * 2,
              lwr = - sd(est.b) * 1.96,
              upr = sd(est.b) * 1.96,
              est = unique(est), dist = unique(dist)
            ) %>% ungroup() %>%
            mutate(rej = 1 * (est < lwr | est > upr),) %>% 
            select(dist, rep, test, rej, pval)
          index = which(is.na(tmp$rej))
          if (length(index) > 0) tmp$rej[index] = 1
          index = which(is.na(tmp$pval))
          if (length(index) > 0) tmp$pval[index] = 0
          tmp
        }) %>% 
        do.call(rbind, .) %>%
        mutate(nsamp = nsamp, tau = tau, true = copula.true, fit = copula.fit)
      summary.all = rbind(summary.all, res)
    }
  }
}
save(summary.all, file = "RData/sizepower_summary.RData") 
stopCluster(cl)