nrep = 500; nboot = 500
source("R/helpers.R")
res.dir = "R/run_results/"
setting.all = purrr::cross(list(nsamp = nsamp.all, tau = tau.all))

execute.fun <- function(copula.true, copula.fit, seed1 = 20210601){
  for (setting in setting.all){
    nsamp = setting$nsamp;  tau = setting$tau
    theta.true = MyTau2Par(copula.true, tau)
    cc = getCopula(copula.true, theta.true)
    set.seed(seed1)
    seed0 = round(runif(nrep, 10, 100000000))
    for (k in 1:nrep){
      filenm = paste0("TRUE", copula.true, "_FIT", copula.fit, 
                      "_nsamp", nsamp, "_tau", tau, "_rep", k)
      if (!file.exists(paste0(res.dir, "true_", copula.true, "/", 
                              filenm, "_", seed1, ".RData"))){
        cat(filenm, ":", sep="")
        t0 = Sys.time()
        set.seed(seed0[k])
        uu = rCopula(nsamp, cc)
        T1 = qexp(1 - uu[,1], rate = 1)
        T2 = qexp(1 - uu[,2], rate = 1)
        res = lapply(cen.dist.all, function(cen.dist0){
          if (cen.dist0 != "none") {
            cen.rate = as.numeric(strsplit(cen.dist0, split = "-")[[1]][2])
            cen.dist = as.character(strsplit(cen.dist0, split = "-")[[1]][1])
          } else {
            cen.dist = cen.dist0
            cen.rate = NULL
          }
          switch(cen.dist,
                 "none"={
                   x1 = T1; x2 = T2
                   d1 = d2 = rep(1, length(T1))
                 },
                 "exp"={
                   C1 = C2 = rexp(nsamp, rate = 1 / (1 - cen.rate) - 1)
                   x1 = pmin(T1, C1); x2 = pmin(T2, C2); 
                   d1 = ifelse(T1 <= C1, 1, 0); d2 = ifelse(T2 <= C2, 1, 0)
                 }
          )
          copula.fam = copula.fit; nsamp = length(x1)
          update.out = update.data(x1, x2, d1, d2, type = "surv")
          distfun.t1 = update.out$distfun.t1; distfun.t2 = update.out$distfun.t2
          IMest = calIM.fun(u1 = update.out$u1, u2 = update.out$u2, 
                              d1 = d1, d2 = d2, copula.fam)
          theta.est = IMest["theta"]
          out = data.frame(value = IMest, para = names(IMest), boot = 0)
          distfun.c = survfit(
            Surv(pmax(x1, x2), 1 * (d1 == 0 | d2 == 0)) ~ 1, 
            se.fit = F, type = "fh2")
          set.seed(seed1)
          seeds_b = round(runif(nboot,10,100000))
          boot_out = foreach (
            b = 1 : nboot,
            .packages = c("survival", "copula", "numDeriv"),
            .combine = rbind) %dopar% {
              source("R_new/helpers.R")
              set.seed(seeds_b[b])
              # generate the bivariate event times (T1,T2)
              cc_b = getCopula(copula.fam, theta.est)
              uu_b = rCopula(nsamp, cc_b)
              t1_b = inv_surv(uu_b[,1], distfun.t1)
              t2_b = inv_surv(uu_b[,2], distfun.t2)
              # generate the censoring through the inverse of its empirical survival
              c1_b = c2_b = inv_surv(runif(nrow(uu_b)), distfun.c) 
              # generate bootstrap data
              x1_b = pmin(t1_b, c1_b); x2_b = pmin(t2_b, c2_b)
              d1_b = ifelse(t1_b <=c1_b, 1, 0); 
              d2_b = ifelse(t2_b <= c2_b, 1, 0)
              update.b = update.data(x1_b, x2_b, d1_b, d2_b)
              IMest.b = calIM.fun(u1 = update.b$u1, u2 = update.b$u2, 
                                    d1 = d1_b, d2 = d2_b, copula.fam)
              data.frame(
                value = IMest.b[-3], para = names(IMest.b)[-3], boot = b
              )
            }
          
          out = rbind(out, boot_out) %>%
            mutate(dist = cen.dist0)
          return(out)
        }) %>% do.call(rbind,.) 
        save(res, file = paste0(res.dir, "true_", copula.true, "/", 
                                filenm, "_", seed1, ".RData"))
        print(Sys.time() - t0)
      }
    }
  }
}
ncl = 6
cl = makeCluster(ncl)
registerDoSNOW(cl)

copula.true.all = copula.fit.all = c("clayton", "frank", "joe", "gaussian")
for (copula.true in copula.true.all){
for (copula.fit in copula.fit.all){
  execute.fun(copula.true = copula.true, copula.fit = copula.fit, 
              seed1 = 20210601)
}
}
stopCluster(cl)
