nrep = 500
res.dir = "R/run_results/" # the folder to save the results from each replicate
setting.all = purrr::cross(list(nsamp = nsamp.all, tau = 0.5))

execute.fun <- function(copula.fam, nrep, seed1=1234){
  ncl = detectCores(logical = FALSE)
  cl = makeCluster(ncl)
  registerDoSNOW(cl)
  lapply(setting.all, function(setting){
    copula.true = copula.fit = copula.fam
    nsamp = setting$nsamp
    tau = setting$tau
    theta.true = MyTau2Par(copula.true, tau)
    cc = getCopula(copula.true, theta.true)
    set.seed(seed1)
    seed0 = round(runif(nrep, 10, 100000000))
    lapply(1 : nrep, function(k){
      filenm = paste0("IRPIOS_", copula.true, "_nsamp", nsamp, 
                      "_tau", tau, "_rep", k)
      if (!file.exists(paste0(res.dir, filenm, "_", seed1, ".RData"))){
        cat(filenm, ":", sep="")
        t0 = Sys.time()
        set.seed(seed0[k])
        uu = rCopula(nsamp, cc)
        T1 = qexp(1 - uu[,1], rate = 1)
        T2 = qexp(1 - uu[,2], rate = 1)
        res = lapply(cen.dist.all, function(cen.dist0){
          if (cen.dist0 != "none") {
            cen.rate = as.numeric(strsplit(cen.dist0, split = "-")[[1]][2])
            cen.dist = as.character(strsplit(cen.dist0, split = "-")[[1]][1])
          } else {
            cen.dist = cen.dist0
            cen.rate = NULL
          }
          switch(cen.dist,
                 "none"={
                   x1 = T1; x2 = T2;
                   d1 = d2 = rep(1, length(T1))
                 },
                 "exp"={
                   C1 = C2 = rexp(nsamp,rate = 1 / (1 - cen.rate) - 1)
                   x1 = pmin(T1, C1); x2 = pmin(T2, C2); 
                   d1 = ifelse(T1 <= C1, 1, 0); d2 = ifelse(T2 <= C2, 1, 0)
                 }
          )
        update.out = update.data(x1 = x1, x2 = x2, d1 = d1, d2 = d2)
        tt1 = Sys.time()
        IR = IR.fun(u1 = update.out$u1, u2 = update.out$u2, d1 = d1, d2 = d2,
                    copula.fam = copula.fit)$IR
        tt.IR = Sys.time() - tt1
        tt1 = Sys.time()
        PIOS = PIOS.fun(u1 = update.out$u1, u2 = update.out$u2, 
                        d1 = d1, d2 = d2,
                        copula.fam = copula.fit, yes.exact = T)$PIOS
        tt.PIOS = Sys.time() - tt1
        data.frame(stat = c("IR", "PIOS"),  value = c(IR, PIOS), 
          time = c(tt.IR, tt.PIOS),  rep = k, dist = cen.dist0)
      }) %>% do.call(rbind,.) %>% 
        as.data.frame() %>%
        mutate(true = copula.true, fit = copula.fit, nsamp = nsamp, tau = tau)
      print(Sys.time() - t0)
      save(res, file= paste0(res.dir, filenm, "_", seed1, ".RData"))
      cat("\n")
    } 
  }) 
  })
  stopCluster(cl)
}
execute.fun(copula.fam = "clayton", nrep = nrep, seed1 = 20210601)
execute.fun(copula.fam = "frank", nrep = nrep, seed1 = 20210601)
execute.fun(copula.fam = "joe", nrep = nrep, seed1 = 20210601)
execute.fun(copula.fam = "gaussian", nrep = nrep, seed1 = 20210601)