nsamp = nrow(mydata)
x1 = mydata$onset[mydata$id == 1]
x2 = mydata$onset[mydata$id == 2]
d1 = mydata$app[mydata$id == 1]
d2 = mydata$app[mydata$id == 2]

update.out = update.data(x1, x2, d1, d2, type = "surv")
u1 = update.out$u1; u2 = update.out$u2
copula.fam.all = c("clayton", "frank", "gumbel", "joe", "gaussian")

ncl = 4
cl = makeCluster(ncl)
registerDoSNOW(cl)

res.all = lapply(copula.fam.all, function(copula.fam){
  res = IMtests_BiSurvCopula(x1 = x1, x2 = x2, d1 = d1, d2 = d2,
                            copula.fam = copula.fam, 
                            control = list(yes.boot = TRUE,
                                           nboot = 1000, 
                                           same.cen = TRUE,
                                           seed1 = 20210823))
  res$fam = copula.fam
  res
})
save(u1, u2, copula.fam.all, res.all, file = "RData/data_res.RData")
stopCluster(cl)


